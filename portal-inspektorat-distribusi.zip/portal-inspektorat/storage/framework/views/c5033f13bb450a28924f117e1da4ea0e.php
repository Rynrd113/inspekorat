<div class="bg-white rounded-lg shadow-md overflow-hidden <?php echo e($attributes->get('class')); ?>" <?php echo e($attributes->except('class')); ?>>
    <?php if(isset($header)): ?>
        <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
            <?php echo e($header); ?>

        </div>
    <?php endif; ?>
    
    <div class="p-6">
        <?php echo e($slot); ?>

    </div>
    
    <?php if(isset($footer)): ?>
        <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
            <?php echo e($footer); ?>

        </div>
    <?php endif; ?>
</div><?php /**PATH /home/rynrd/Documents/Project/portal-inspektorat/resources/views/components/card.blade.php ENDPATH**/ ?>