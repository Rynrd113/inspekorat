<?php
$inputClasses = 'block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors';
if ($error) {
    $inputClasses .= ' border-red-300 focus:border-red-500 focus:ring-red-500';
}
?>

<div class="mb-4">
    <?php if($label): ?>
        <label for="<?php echo e($attributes->get('id', $attributes->get('name'))); ?>" class="block text-sm font-medium text-gray-700 mb-2">
            <?php echo e($label); ?>

            <?php if($required): ?>
                <span class="text-red-500">*</span>
            <?php endif; ?>
        </label>
    <?php endif; ?>
    
    <?php if($type === 'textarea'): ?>
        <textarea 
            class="<?php echo e($inputClasses); ?> <?php echo e($attributes->get('class')); ?>"
            placeholder="<?php echo e($placeholder); ?>"
            <?php echo e($required ? 'required' : ''); ?>

            <?php echo e($attributes->except(['class', 'type'])); ?>

        ><?php echo e($slot); ?></textarea>
    <?php else: ?>
        <input 
            type="<?php echo e($type); ?>"
            class="<?php echo e($inputClasses); ?> <?php echo e($attributes->get('class')); ?>"
            placeholder="<?php echo e($placeholder); ?>"
            <?php echo e($required ? 'required' : ''); ?>

            <?php echo e($attributes->except(['class', 'type'])); ?>

        />
    <?php endif; ?>
    
    <?php if($error): ?>
        <p class="mt-1 text-sm text-red-600"><?php echo e($error); ?></p>
    <?php endif; ?>
</div><?php /**PATH /home/rynrd/Documents/Project/portal-inspektorat/resources/views/components/input.blade.php ENDPATH**/ ?>